Put authorised photographs here and reference them in src/data/content.js (gallery[].src, hero).
